package com.ch04;


import android.app.Activity;
import android.os.Bundle;

public class NewActivity extends Activity {
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);
        
    }
}
